library(Rgraphviz)
Ragraph <- agopen(myGraph, "myGraph")

library(gridGraphviz)
png("example.png")
grid.graph(Ragraph, newpage=TRUE)
dev.off()
